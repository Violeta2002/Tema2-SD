// Copyright 2021-2022 Comsa Iuliana Violeta <comsa.iulianavioleta@gmail.com>
#ifndef HOME_STUDENT_TEMA2_SD_GET_H_
#define HOME_STUDENT_TEMA2_SD_GET_H_

void get_book(hashtable_t *ht, char *params);

void get_def(hashtable_t *ht, char *params);

#endif  // HOME_STUDENT_TEMA2_SD_GET_H_
