// Copyright 2021-2022 Comsa Iuliana Violeta <comsa.iulianavioleta@gmail.com>
#ifndef HOME_STUDENT_TEMA2_SD_EXIT_H_
#define HOME_STUDENT_TEMA2_SD_EXIT_H_

void ht_free_book(hashtable_t **ht, char *book_name);

void ht_exit(hashtable_t **ht);

#endif  // HOME_STUDENT_TEMA2_SD_EXIT_H_
