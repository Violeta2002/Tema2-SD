// Copyright 2021-2022 Comsa Iuliana Violeta <comsa.iulianavioleta@gmail.com>
#ifndef HOME_STUDENT_TEMA2_SD_TOP_USERS_H_
#define HOME_STUDENT_TEMA2_SD_TOP_USERS_H_

void sort_users(info *users, int nr);

void top_users(hashtable_t *ht);

#endif  // HOME_STUDENT_TEMA2_SD_TOP_USERS_H_
